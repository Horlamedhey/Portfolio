<!DOCTYPE html>
<html>
	<head>
		<title>about</title>
		<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=yes">
		<link rel="stylesheet" type="text/css" href="css/animate.css">
		<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
	</head>
	<body onscroll="navwidabt()">
		<div class="ent" id="ent">
			<divid="entdiv">OYE & SONS ELECTRICAL AND ELECTRONICS CORPORATIONS</div>
		</div>
		<div class="lododiv" id="logodiv"><a href="index.php"><img src="images/3.jpeg" class="logo" id="logo"></a></div>
		<nav id="nav" onmouseover="swapcolorabt1()" onmouseout="swapcolorabt2()">
			<a href="home.php" id="a1">Home</a>
			<a href="about.php" id="a2">About us</a>
			<a href="contact.php" id="a3">Contact us</a>
			<a href="register.php" id="a4">Register</a>
			<a href="login.php" id="a5">Login</a>
			<a href="form.php" id="a6">Login/Register</a>
			<a href="profile.php" id="a7">Profile</a>
		<a href="form.html" id="a8">Login/Register</a>
		</nav>
		<div class="abtus animated lightSpeedIn" id="abtus">ABOUT US</div>
		<img src="images/25.jpeg" class="col-12 abtimg animated fadeInUp" id="abtimg">
		<div class="col-12 abtdiv">
			<div class="abtcntntdiv">
				<div class="col-5 off-0-5 float">
					<div class="center abthead">OUR HISTORY</div>
					<p class="justify abtxts">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					</p>
				</div>
				<img src="images/29.jpeg" class="col-5 off-1 cntntimgs">
			</div>
			<div class="abtcntntdiv">
				<div class="col-5 off-0-5 float">
					<div class="center abthead">OUR STANDARD</div>
					<p class="justify abtxts">
						We have the largerst stock in the world, ranging from; High quality electrical materials, equipments and machines, such as; Wires, Cables, Chords, Sockets, Pipe, Tapes, cutter, Driller, e.t.c... Best quality of electronic appliances such as; LCD TVs, Microwaves, Home theaters, Deep freezers and many more.
					</p>
				</div>
				<img src="images/40.jpg" class="col-5 off-1 cntntimgs">
			</div>
			<div class="abtcntntdiv">
				<div class="col-5 off-0-5 float">
					<div class="center abthead">OUR VISION</div>
					<p class="justify abtxts">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					</p>
				</div>
				<img src="images/36.jpg" class="col-5 off-1 cntntimgs">
			</div>
			<div class="abtcntntdiv">
				<div class="col-5 off-0-5 float">
					<div class="center abthead">OUR MISSION</div>
					<p class="justify abtxts">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					</p>
				</div>
				<img src="images/37.jpg" class="col-5 off-1 cntntimgs">
			</div>
			<div class="abtcntntdiv">
				<div class="col-5 off-0-5 float">
					<div class="center abthead">OUR VALUES</div>
					<p class="justify abtxts">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					</p>
				</div>
				<img src="images/39.jpg" class="col-5 off-1 cntntimgs">
			</div>
			<div class="abtcntntdiv">
				<div class="col-5 off-0-5 float">
					<div class="center abthead">INTERNET FRAUD</div>
					<p class="justify abtxts">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					</p>
				</div>
				<img src="images/35.jpeg" class="col-5 off-1 cntntimgs">
			</div>
		</div>
		<div class="team">Team members</div>
		<div class="col-12 teamdiv">
			<div class="col-3 off-4-5">
				<div class="teambg1"><img src="images/tm1.jpg"></div>
				<div class="teamdetails">
					<div>Name: Engr. Ajao Gafar Olamide</div>
					<div>Post: C.E.O</div>
					<div>Year: 1999</div>
				</div>
			</div>
			<div class="col-3 off-0-5 float">
				<div class="teambg1"><img src="images/tm4.jpg"></div>
				<div class="teamdetails">
					<div>Name: Engr. Tafa Shola</div>
					<div>Post: Managing Director</div>
					<div>Year: 1999</div>
				</div>
			</div>
			<div class="col-3 off-1 float">
				<div class="teambg1"><img src="images/tm6.jpg"></div>
				<div class="teamdetails">
					<div>Name: Engr. Temitope Omisakin</div>
					<div>Post: Chief Officer</div>
					<div>Year: 1999</div>
				</div>
			</div>
			<div class="col-3 off-1 float">
				<div class="teambg1"><img src="images/tm7.jpg"></div>
				<div class="teamdetails">
					<div>Name: Engr. Oluwasegun Micheal</div>
					<div>Post: General Secretary</div>
					<div>Year: 1999</div>
				</div>
			</div>
			<div class="col-3 off-0-5 float">
				<div class="teambg1"><img src="images/tm2.jpg"></div>
				<div class="teamdetails">
					<div>Name: Engr. Muiz Anjuwon</div>
					<div>Post: Field Manager 1</div>
					<div>Year: 2005</div>
				</div>
			</div>
			<div class="col-3 off-1 float">
				<div class="teambg1"><img src="images/tm3.jpg"></div>
				<div class="teamdetails">
					<div>Name: Engr. Rasheed Kampala</div>
					<div>Post: Maintenance Officer</div>
					<div>Year: 2009</div>
				</div>
			</div>
			<div class="col-3 off-1 float">
				<div class="teambg1"><img src="images/tm2.jpg"></div>
				<div class="teamdetails">
					<div>Name: Engr. Oluwasegun Orobo</div>
					<div>Post: Architecture Officer</div>
					<div>Year: 2003</div>
				</div>
			</div>
			<div class="col-3 off-0-5 float">
				<div class="teambg1"><img src="images/tm5.jpg"></div>
				<div class="teamdetails">
					<div>Name: Engr. Diyaolu Mariam</div>
					<div>Post: Field Manager 2</div>
					<div>Year:2014</div>
				</div>
			</div>
			<div class="col-3 off-1 float">
				<div class="teambg1"><img src="images/tm8.jpg"></div>
				<div class="teamdetails">
					<div>Name: Mr. Ogo-Oluwa Bright</div>
					<div>Post: Office Assistant</div>
					<div>Year: 2015</div>
				</div>
			</div>
			<div class="col-3 off-1 float">
				<div class="teambg1"><img src="images/tm9.jpg"></div>
				<div class="teamdetails">
					<div>Name: Mr. Ajanlekoko Ajiun</div>
					<div>Post: Personal Assistant</div>
					<div>Year: 1999</div>
				</div>
			</div>
		</div>
		<div class="footer abtfooter">
			<div class="abticondiv">
				<a href="" class="map">Site Map <i class="fa fa-sitemap"></i></a>
				<div class="iconsubdiv">
					<i class="fa fa-facebook-official"></i>
					<i class="fa fa-twitter-square"></i>
					<i class="fa fa-google-plus"></i>
				</div>
				<a href="#entdiv" class="top">Top <i class="fa fa-home"></i></a>
			</div>
			<div class="abtcopydiv"><i class="fa fa-copyright"></i> 2017. All Rights Reserved</div>
		</div>
	</body>
	<script type="text/javascript" src="js/script.js"></script>
</html>