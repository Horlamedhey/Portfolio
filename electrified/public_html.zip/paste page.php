<?php 
		if (@$_GET['login']=="false") {
			echo "<div class='noacct'>Sorry, you do not have an account yet...Fill the form below to create one!</div>";
		} ?>